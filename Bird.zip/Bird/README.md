# JS-Flappy-Bird
Remake of the Original FlappyBird Using **JS** &amp; **HTML Canvas** 
# [Play it.](https://aaarafat.github.io/JS-Flappy-Bird/index.html)
# Demo
![Demo](https://user-images.githubusercontent.com/44725090/67148880-e7dba280-f2a4-11e9-8dbf-d154842ee0cf.gif)
